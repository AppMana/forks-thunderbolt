savedcmd_thunderbolt_ibverbs.o := ld -m elf_x86_64 -z noexecstack --no-warn-rwx-segments   -r -o thunderbolt_ibverbs.o @thunderbolt_ibverbs.mod 
