#include <linux/module.h>
#include <linux/export-internal.h>
#include <linux/compiler.h>

MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};



static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0x02cc4082, "tb_xdomain_alloc_out_hopid" },
	{ 0xf839743b, "tb_xdomain_type" },
	{ 0xc45d298e, "is_vmalloc_addr" },
	{ 0xd98156e2, "ida_alloc_range" },
	{ 0x69bc4f39, "ib_umem_release" },
	{ 0xd272d446, "rtnl_unlock" },
	{ 0x751428af, "tb_ring_start" },
	{ 0x740648c4, "ida_destroy" },
	{ 0x41240aa5, "tb_property_create_dir" },
	{ 0x4d8419c6, "param_ops_uint" },
	{ 0xf5ef60bd, "skb_put" },
	{ 0xd272d446, "__rcu_read_lock" },
	{ 0x534ed5f3, "__msecs_to_jiffies" },
	{ 0xd710adbf, "__kmalloc_noprof" },
	{ 0x9c662f86, "__tb_ring_enqueue" },
	{ 0xc7c215d6, "tb_xdomain_enable_paths" },
	{ 0x40a621c5, "snprintf" },
	{ 0x65026e43, "complete" },
	{ 0x49733ad6, "queue_work_on" },
	{ 0xabdb103e, "trace_raw_output_prep" },
	{ 0x4ef4b174, "__symbol_put" },
	{ 0xdd45951a, "sysfs_streq" },
	{ 0x3a645690, "__bitmap_weight" },
	{ 0x60c9c0b3, "__init_swait_queue_head" },
	{ 0xfccc5035, "__trace_trigger_soft_disabled" },
	{ 0xc87f4bab, "finish_wait" },
	{ 0xeff53529, "dma_unmap_page_attrs" },
	{ 0x963a020b, "trace_event_printf" },
	{ 0xbd03ed67, "this_cpu_off" },
	{ 0xaae51a71, "ib_modify_qp_is_ok" },
	{ 0x97c20d46, "__xa_erase" },
	{ 0x751428af, "tb_ring_free" },
	{ 0x4974b3b2, "trace_event_raw_init" },
	{ 0xa53f4e29, "memcpy" },
	{ 0xcb8b6ec6, "kfree" },
	{ 0xef9f4380, "rdma_query_gid" },
	{ 0xd5bc7086, "seq_lseek" },
	{ 0x0db8d68d, "prepare_to_wait_event" },
	{ 0x72b9e7b1, "tb_ring_alloc_tx" },
	{ 0x16ab4215, "__wake_up" },
	{ 0x184529f1, "get_device" },
	{ 0x282f983f, "bpf_trace_run8" },
	{ 0xed460a89, "_ib_alloc_device" },
	{ 0xe1e1f979, "_raw_spin_lock_irqsave" },
	{ 0xd65731f8, "__dynamic_dev_dbg" },
	{ 0xb86c2a81, "tb_xdomain_release_out_hopid" },
	{ 0xd272d446, "__fentry__" },
	{ 0xd091b262, "configfs_unregister_subsystem" },
	{ 0xdd6830c7, "sysfs_emit" },
	{ 0x2920b270, "dev_driver_string" },
	{ 0x9c0c38e8, "trace_event_buffer_commit" },
	{ 0x11f81cd8, "ib_unregister_device" },
	{ 0x5a844b26, "__x86_indirect_thunk_rax" },
	{ 0xa04364ba, "dma_map_page_attrs" },
	{ 0xe8213e80, "_printk" },
	{ 0xbd03ed67, "__ref_stack_chk_guard" },
	{ 0xff7fbdd1, "___ratelimit" },
	{ 0x6ac784f4, "schedule_timeout" },
	{ 0x21db48d9, "ib_register_device" },
	{ 0x9a1b2a81, "netdev_rx_handler_unregister" },
	{ 0xd272d446, "__stack_chk_fail" },
	{ 0x2520ea93, "refcount_warn_saturate" },
	{ 0x8ce83585, "queue_delayed_work_on" },
	{ 0xd4a4112c, "put_device" },
	{ 0xb86c2a81, "tb_xdomain_release_in_hopid" },
	{ 0xd710adbf, "__kmalloc_large_noprof" },
	{ 0x9479a1e8, "strnlen" },
	{ 0xfd285498, "unregister_inetaddr_notifier" },
	{ 0x6d4247dd, "__free_pages" },
	{ 0xb760ce2d, "tb_unregister_protocol_handler" },
	{ 0x90a48d82, "__ubsan_handle_out_of_bounds" },
	{ 0xbd03ed67, "page_offset_base" },
	{ 0xfa1297b2, "tb_property_free_dir" },
	{ 0xd70733be, "sized_strscpy" },
	{ 0xb1390e2f, "__symbol_get" },
	{ 0xe511447d, "__dma_sync_single_for_cpu" },
	{ 0x7a5ffe84, "init_wait_entry" },
	{ 0x98aacd62, "perf_trace_buf_alloc" },
	{ 0x2dcd2c88, "perf_trace_run_bpf_submit" },
	{ 0xb1172073, "init_net" },
	{ 0xd5e4e510, "configfs_register_subsystem" },
	{ 0xd272d446, "__rcu_read_unlock" },
	{ 0x5a844b26, "__x86_indirect_thunk_r14" },
	{ 0xb8b52271, "config_group_init_type_name" },
	{ 0x8db9b6ac, "__usecs_to_jiffies" },
	{ 0xbd03ed67, "random_kmalloc_seed" },
	{ 0xd7a59a65, "vmalloc_noprof" },
	{ 0x543d45da, "ib_device_set_netdev" },
	{ 0xb30edde4, "ib_umem_get" },
	{ 0xbeb1d261, "destroy_workqueue" },
	{ 0x308fece2, "xas_load" },
	{ 0xf46d5bf3, "mutex_lock" },
	{ 0x74fc8c8a, "debugfs_remove" },
	{ 0x8278bce6, "trace_event_reg" },
	{ 0x4c3d335e, "ida_free" },
	{ 0x8ce83585, "mod_delayed_work_on" },
	{ 0xbd03ed67, "phys_base" },
	{ 0xb5c51982, "__cpu_online_mask" },
	{ 0x402db74e, "memcmp" },
	{ 0x931419a6, "tb_register_service_driver" },
	{ 0x173ec8da, "sscanf" },
	{ 0xc1e6c71e, "__mutex_init" },
	{ 0xe54e0a6b, "__fortify_panic" },
	{ 0xe199f25f, "jiffies_to_msecs" },
	{ 0x81a1a811, "_raw_spin_unlock_irqrestore" },
	{ 0x02cc4082, "tb_xdomain_alloc_in_hopid" },
	{ 0xc61bbb47, "tb_xdomain_response" },
	{ 0xb5c51982, "__cpu_possible_mask" },
	{ 0x27683a56, "memset" },
	{ 0x1fab9beb, "tb_register_property_dir" },
	{ 0x5a844b26, "__x86_indirect_thunk_r10" },
	{ 0x4d8419c6, "param_ops_charp" },
	{ 0x65026e43, "wait_for_completion" },
	{ 0xbeb1d261, "__flush_workqueue" },
	{ 0xd272d446, "__x86_return_thunk" },
	{ 0x386e4ba3, "kmemdup_noprof" },
	{ 0xf296206e, "nr_cpu_ids" },
	{ 0x5403c125, "__init_waitqueue_head" },
	{ 0x98115f5f, "__pskb_pull_tail" },
	{ 0xec1444cd, "__netdev_alloc_skb" },
	{ 0x336b9888, "ib_dealloc_device" },
	{ 0xf0995667, "tb_unregister_property_dir" },
	{ 0xaef1f20d, "system_long_wq" },
	{ 0x888b8f57, "strcmp" },
	{ 0xfd285498, "unregister_netdevice_notifier" },
	{ 0x058c185a, "jiffies" },
	{ 0x443e66a8, "__xa_insert" },
	{ 0xfc8971f4, "bpf_trace_run3" },
	{ 0x11bacf83, "seq_read" },
	{ 0x8bc8f40f, "crc32c" },
	{ 0xbd03ed67, "vmemmap_base" },
	{ 0xd1ddcf19, "tb_property_add_immediate" },
	{ 0x82fd7238, "__ubsan_handle_shift_out_of_bounds" },
	{ 0x7ec472ba, "cpu_number" },
	{ 0x7ec472ba, "__preempt_count" },
	{ 0xafb85506, "tb_register_protocol_handler" },
	{ 0x56e7eadc, "__dev_queue_xmit" },
	{ 0xf1de9e85, "vfree" },
	{ 0x842d17bc, "trace_event_buffer_reserve" },
	{ 0xf46d5bf3, "mutex_unlock" },
	{ 0x85acaba2, "cancel_delayed_work_sync" },
	{ 0xacd52f9b, "config_item_init_type_name" },
	{ 0x4d8419c6, "param_ops_bool" },
	{ 0xe511447d, "__dma_sync_single_for_device" },
	{ 0x3017bf34, "xa_destroy" },
	{ 0xb1cc00da, "sg_pcopy_from_buffer" },
	{ 0xf74a5c79, "tb_unregister_service_driver" },
	{ 0x23f25c0a, "__dynamic_pr_debug" },
	{ 0xecd17989, "__kmalloc_cache_noprof" },
	{ 0x2d88a3ab, "cancel_work_sync" },
	{ 0x75738bed, "__warn_printk" },
	{ 0xfd285498, "register_netdevice_notifier" },
	{ 0x0d8b6c91, "seq_printf" },
	{ 0x751428af, "tb_ring_poll_complete" },
	{ 0x104505a0, "tb_ring_alloc_rx" },
	{ 0x71798f7e, "delayed_work_timer_fn" },
	{ 0x21ce222f, "dev_get_by_name" },
	{ 0x751428af, "tb_ring_stop" },
	{ 0x6d2a89ad, "debugfs_create_file_full" },
	{ 0x58914088, "nsecs_to_jiffies" },
	{ 0xd272d446, "rtnl_lock" },
	{ 0x4df3ea62, "alloc_pages_noprof" },
	{ 0xf46066ae, "tb_xdomain_request" },
	{ 0xf5f747d6, "netdev_rx_handler_register" },
	{ 0xaef1f20d, "system_unbound_wq" },
	{ 0x024d45a2, "single_release" },
	{ 0x02f9bbf0, "timer_init_key" },
	{ 0x2b76adaa, "tb_ring_poll" },
	{ 0x5a844b26, "__x86_indirect_thunk_r12" },
	{ 0xfd285498, "register_inetaddr_notifier" },
	{ 0xdf4bee3d, "alloc_workqueue_noprof" },
	{ 0xe4de56b4, "__ubsan_handle_load_invalid_value" },
	{ 0x43a349ca, "strlen" },
	{ 0x3a31882a, "ib_umem_copy_from" },
	{ 0x4d8419c6, "param_ops_int" },
	{ 0xf1de9e85, "kvfree" },
	{ 0xd272d446, "__SCT__preempt_schedule_notrace" },
	{ 0xce105414, "single_open" },
	{ 0xc7c215d6, "tb_xdomain_disable_paths" },
	{ 0x2379af1d, "debugfs_create_dir" },
	{ 0x90bf627e, "__kvmalloc_node_noprof" },
	{ 0x955467e2, "trace_handle_return" },
	{ 0x67b2ba98, "sysfs_emit_at" },
	{ 0x67628f51, "msleep" },
	{ 0x7851be11, "__SCT__might_resched" },
	{ 0xebef3db0, "pci_bus_type" },
	{ 0x08bfc903, "kmalloc_caches" },
	{ 0x929b135d, "ib_set_device_ops" },
	{ 0xce1b1116, "tb_xdomain_lane_bonding_enable" },
	{ 0xaef1f20d, "system_wq" },
	{ 0x814e12e5, "module_layout" },
};

static const u32 ____version_ext_crcs[]
__used __section("__version_ext_crcs") = {
	0x02cc4082,
	0xf839743b,
	0xc45d298e,
	0xd98156e2,
	0x69bc4f39,
	0xd272d446,
	0x751428af,
	0x740648c4,
	0x41240aa5,
	0x4d8419c6,
	0xf5ef60bd,
	0xd272d446,
	0x534ed5f3,
	0xd710adbf,
	0x9c662f86,
	0xc7c215d6,
	0x40a621c5,
	0x65026e43,
	0x49733ad6,
	0xabdb103e,
	0x4ef4b174,
	0xdd45951a,
	0x3a645690,
	0x60c9c0b3,
	0xfccc5035,
	0xc87f4bab,
	0xeff53529,
	0x963a020b,
	0xbd03ed67,
	0xaae51a71,
	0x97c20d46,
	0x751428af,
	0x4974b3b2,
	0xa53f4e29,
	0xcb8b6ec6,
	0xef9f4380,
	0xd5bc7086,
	0x0db8d68d,
	0x72b9e7b1,
	0x16ab4215,
	0x184529f1,
	0x282f983f,
	0xed460a89,
	0xe1e1f979,
	0xd65731f8,
	0xb86c2a81,
	0xd272d446,
	0xd091b262,
	0xdd6830c7,
	0x2920b270,
	0x9c0c38e8,
	0x11f81cd8,
	0x5a844b26,
	0xa04364ba,
	0xe8213e80,
	0xbd03ed67,
	0xff7fbdd1,
	0x6ac784f4,
	0x21db48d9,
	0x9a1b2a81,
	0xd272d446,
	0x2520ea93,
	0x8ce83585,
	0xd4a4112c,
	0xb86c2a81,
	0xd710adbf,
	0x9479a1e8,
	0xfd285498,
	0x6d4247dd,
	0xb760ce2d,
	0x90a48d82,
	0xbd03ed67,
	0xfa1297b2,
	0xd70733be,
	0xb1390e2f,
	0xe511447d,
	0x7a5ffe84,
	0x98aacd62,
	0x2dcd2c88,
	0xb1172073,
	0xd5e4e510,
	0xd272d446,
	0x5a844b26,
	0xb8b52271,
	0x8db9b6ac,
	0xbd03ed67,
	0xd7a59a65,
	0x543d45da,
	0xb30edde4,
	0xbeb1d261,
	0x308fece2,
	0xf46d5bf3,
	0x74fc8c8a,
	0x8278bce6,
	0x4c3d335e,
	0x8ce83585,
	0xbd03ed67,
	0xb5c51982,
	0x402db74e,
	0x931419a6,
	0x173ec8da,
	0xc1e6c71e,
	0xe54e0a6b,
	0xe199f25f,
	0x81a1a811,
	0x02cc4082,
	0xc61bbb47,
	0xb5c51982,
	0x27683a56,
	0x1fab9beb,
	0x5a844b26,
	0x4d8419c6,
	0x65026e43,
	0xbeb1d261,
	0xd272d446,
	0x386e4ba3,
	0xf296206e,
	0x5403c125,
	0x98115f5f,
	0xec1444cd,
	0x336b9888,
	0xf0995667,
	0xaef1f20d,
	0x888b8f57,
	0xfd285498,
	0x058c185a,
	0x443e66a8,
	0xfc8971f4,
	0x11bacf83,
	0x8bc8f40f,
	0xbd03ed67,
	0xd1ddcf19,
	0x82fd7238,
	0x7ec472ba,
	0x7ec472ba,
	0xafb85506,
	0x56e7eadc,
	0xf1de9e85,
	0x842d17bc,
	0xf46d5bf3,
	0x85acaba2,
	0xacd52f9b,
	0x4d8419c6,
	0xe511447d,
	0x3017bf34,
	0xb1cc00da,
	0xf74a5c79,
	0x23f25c0a,
	0xecd17989,
	0x2d88a3ab,
	0x75738bed,
	0xfd285498,
	0x0d8b6c91,
	0x751428af,
	0x104505a0,
	0x71798f7e,
	0x21ce222f,
	0x751428af,
	0x6d2a89ad,
	0x58914088,
	0xd272d446,
	0x4df3ea62,
	0xf46066ae,
	0xf5f747d6,
	0xaef1f20d,
	0x024d45a2,
	0x02f9bbf0,
	0x2b76adaa,
	0x5a844b26,
	0xfd285498,
	0xdf4bee3d,
	0xe4de56b4,
	0x43a349ca,
	0x3a31882a,
	0x4d8419c6,
	0xf1de9e85,
	0xd272d446,
	0xce105414,
	0xc7c215d6,
	0x2379af1d,
	0x90bf627e,
	0x955467e2,
	0x67b2ba98,
	0x67628f51,
	0x7851be11,
	0xebef3db0,
	0x08bfc903,
	0x929b135d,
	0xce1b1116,
	0xaef1f20d,
	0x814e12e5,
};
static const char ____version_ext_names[]
__used __section("__version_ext_names") =
	"tb_xdomain_alloc_out_hopid\0"
	"tb_xdomain_type\0"
	"is_vmalloc_addr\0"
	"ida_alloc_range\0"
	"ib_umem_release\0"
	"rtnl_unlock\0"
	"tb_ring_start\0"
	"ida_destroy\0"
	"tb_property_create_dir\0"
	"param_ops_uint\0"
	"skb_put\0"
	"__rcu_read_lock\0"
	"__msecs_to_jiffies\0"
	"__kmalloc_noprof\0"
	"__tb_ring_enqueue\0"
	"tb_xdomain_enable_paths\0"
	"snprintf\0"
	"complete\0"
	"queue_work_on\0"
	"trace_raw_output_prep\0"
	"__symbol_put\0"
	"sysfs_streq\0"
	"__bitmap_weight\0"
	"__init_swait_queue_head\0"
	"__trace_trigger_soft_disabled\0"
	"finish_wait\0"
	"dma_unmap_page_attrs\0"
	"trace_event_printf\0"
	"this_cpu_off\0"
	"ib_modify_qp_is_ok\0"
	"__xa_erase\0"
	"tb_ring_free\0"
	"trace_event_raw_init\0"
	"memcpy\0"
	"kfree\0"
	"rdma_query_gid\0"
	"seq_lseek\0"
	"prepare_to_wait_event\0"
	"tb_ring_alloc_tx\0"
	"__wake_up\0"
	"get_device\0"
	"bpf_trace_run8\0"
	"_ib_alloc_device\0"
	"_raw_spin_lock_irqsave\0"
	"__dynamic_dev_dbg\0"
	"tb_xdomain_release_out_hopid\0"
	"__fentry__\0"
	"configfs_unregister_subsystem\0"
	"sysfs_emit\0"
	"dev_driver_string\0"
	"trace_event_buffer_commit\0"
	"ib_unregister_device\0"
	"__x86_indirect_thunk_rax\0"
	"dma_map_page_attrs\0"
	"_printk\0"
	"__ref_stack_chk_guard\0"
	"___ratelimit\0"
	"schedule_timeout\0"
	"ib_register_device\0"
	"netdev_rx_handler_unregister\0"
	"__stack_chk_fail\0"
	"refcount_warn_saturate\0"
	"queue_delayed_work_on\0"
	"put_device\0"
	"tb_xdomain_release_in_hopid\0"
	"__kmalloc_large_noprof\0"
	"strnlen\0"
	"unregister_inetaddr_notifier\0"
	"__free_pages\0"
	"tb_unregister_protocol_handler\0"
	"__ubsan_handle_out_of_bounds\0"
	"page_offset_base\0"
	"tb_property_free_dir\0"
	"sized_strscpy\0"
	"__symbol_get\0"
	"__dma_sync_single_for_cpu\0"
	"init_wait_entry\0"
	"perf_trace_buf_alloc\0"
	"perf_trace_run_bpf_submit\0"
	"init_net\0"
	"configfs_register_subsystem\0"
	"__rcu_read_unlock\0"
	"__x86_indirect_thunk_r14\0"
	"config_group_init_type_name\0"
	"__usecs_to_jiffies\0"
	"random_kmalloc_seed\0"
	"vmalloc_noprof\0"
	"ib_device_set_netdev\0"
	"ib_umem_get\0"
	"destroy_workqueue\0"
	"xas_load\0"
	"mutex_lock\0"
	"debugfs_remove\0"
	"trace_event_reg\0"
	"ida_free\0"
	"mod_delayed_work_on\0"
	"phys_base\0"
	"__cpu_online_mask\0"
	"memcmp\0"
	"tb_register_service_driver\0"
	"sscanf\0"
	"__mutex_init\0"
	"__fortify_panic\0"
	"jiffies_to_msecs\0"
	"_raw_spin_unlock_irqrestore\0"
	"tb_xdomain_alloc_in_hopid\0"
	"tb_xdomain_response\0"
	"__cpu_possible_mask\0"
	"memset\0"
	"tb_register_property_dir\0"
	"__x86_indirect_thunk_r10\0"
	"param_ops_charp\0"
	"wait_for_completion\0"
	"__flush_workqueue\0"
	"__x86_return_thunk\0"
	"kmemdup_noprof\0"
	"nr_cpu_ids\0"
	"__init_waitqueue_head\0"
	"__pskb_pull_tail\0"
	"__netdev_alloc_skb\0"
	"ib_dealloc_device\0"
	"tb_unregister_property_dir\0"
	"system_long_wq\0"
	"strcmp\0"
	"unregister_netdevice_notifier\0"
	"jiffies\0"
	"__xa_insert\0"
	"bpf_trace_run3\0"
	"seq_read\0"
	"crc32c\0"
	"vmemmap_base\0"
	"tb_property_add_immediate\0"
	"__ubsan_handle_shift_out_of_bounds\0"
	"cpu_number\0"
	"__preempt_count\0"
	"tb_register_protocol_handler\0"
	"__dev_queue_xmit\0"
	"vfree\0"
	"trace_event_buffer_reserve\0"
	"mutex_unlock\0"
	"cancel_delayed_work_sync\0"
	"config_item_init_type_name\0"
	"param_ops_bool\0"
	"__dma_sync_single_for_device\0"
	"xa_destroy\0"
	"sg_pcopy_from_buffer\0"
	"tb_unregister_service_driver\0"
	"__dynamic_pr_debug\0"
	"__kmalloc_cache_noprof\0"
	"cancel_work_sync\0"
	"__warn_printk\0"
	"register_netdevice_notifier\0"
	"seq_printf\0"
	"tb_ring_poll_complete\0"
	"tb_ring_alloc_rx\0"
	"delayed_work_timer_fn\0"
	"dev_get_by_name\0"
	"tb_ring_stop\0"
	"debugfs_create_file_full\0"
	"nsecs_to_jiffies\0"
	"rtnl_lock\0"
	"alloc_pages_noprof\0"
	"tb_xdomain_request\0"
	"netdev_rx_handler_register\0"
	"system_unbound_wq\0"
	"single_release\0"
	"timer_init_key\0"
	"tb_ring_poll\0"
	"__x86_indirect_thunk_r12\0"
	"register_inetaddr_notifier\0"
	"alloc_workqueue_noprof\0"
	"__ubsan_handle_load_invalid_value\0"
	"strlen\0"
	"ib_umem_copy_from\0"
	"param_ops_int\0"
	"kvfree\0"
	"__SCT__preempt_schedule_notrace\0"
	"single_open\0"
	"tb_xdomain_disable_paths\0"
	"debugfs_create_dir\0"
	"__kvmalloc_node_noprof\0"
	"trace_handle_return\0"
	"sysfs_emit_at\0"
	"msleep\0"
	"__SCT__might_resched\0"
	"pci_bus_type\0"
	"kmalloc_caches\0"
	"ib_set_device_ops\0"
	"tb_xdomain_lane_bonding_enable\0"
	"system_wq\0"
	"module_layout\0"
;

MODULE_INFO(depends, "thunderbolt,ib_uverbs,ib_core");

MODULE_ALIAS("tbsvc:ktbverbsp00000001v*r*");
MODULE_ALIAS("tbsvc:ktbverb1p00000001v*r*");
MODULE_ALIAS("tbsvc:ktbverb2p00000001v*r*");
MODULE_ALIAS("tbsvc:ktbverb3p00000001v*r*");
MODULE_ALIAS("tbsvc:k*p0000FA57v00000001r00000000*");

MODULE_INFO(srcversion, "EDDF6CFD85E4B14F2FD140F");
